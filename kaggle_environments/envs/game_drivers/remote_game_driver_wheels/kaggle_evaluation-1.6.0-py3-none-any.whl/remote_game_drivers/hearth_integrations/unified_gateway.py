"""Unified Hearth gateway that supports Gymnasium, PettingZoo, Shimmy, and custom games.

Game names must be fully qualified with a framework prefix:
- 'pettingzoo.classic.tictactoe_v3' -> PettingZoo
- 'shimmy.tic_tac_toe' -> Shimmy/OpenSpiel
- 'gymnasium.Blackjack-v1' -> Gymnasium

Unknown prefixes will raise an error to avoid silent failures.
"""

import importlib

import kaggle_evaluation.core.base_gateway
import kaggle_evaluation.core.templates

# IMPORTANT: Install wheels before importing from remote_game_drivers
from remote_game_drivers.hearth_integrations.install_wheels import install_remote_game_drivers

install_remote_game_drivers()

from remote_game_drivers.core.base_classes import KaggleAgentId

# Known framework prefixes - add new frameworks here
KNOWN_FRAMEWORKS = {'gymnasium', 'pettingzoo', 'shimmy'}


def detect_framework(game_name: str) -> str:
    """Detect the game framework from the game name prefix.

    Game names must be fully qualified with a framework prefix:
    - 'pettingzoo.classic.tictactoe_v3' -> 'pettingzoo'
    - 'shimmy.tic_tac_toe' -> 'shimmy'
    - 'gymnasium.Blackjack-v1' -> 'gymnasium'

    Raises:
        GatewayRuntimeError: If the game name doesn't have a recognized framework prefix.
    """
    prefix = game_name.split('.')[0] if '.' in game_name else None

    if prefix in KNOWN_FRAMEWORKS:
        return prefix

    raise kaggle_evaluation.core.base_gateway.GatewayRuntimeError(
        kaggle_evaluation.core.base_gateway.GatewayRuntimeErrorType.GATEWAY_RAISED_EXCEPTION,
        f"Unknown framework prefix in game name '{game_name}'. "
        f'Game names must start with a known framework prefix: {sorted(KNOWN_FRAMEWORKS)}. '
        f"For example: 'pettingzoo.classic.tictactoe_v3' or 'gymnasium.Blackjack-v1'.",
    )


def strip_framework_prefix(game_name: str) -> str:
    """Strip the framework prefix from a game name.

    'shimmy.tic_tac_toe' -> 'tic_tac_toe'
    'pettingzoo.classic.tictactoe_v3' -> 'classic.tictactoe_v3'
    'gymnasium.Blackjack-v1' -> 'Blackjack-v1'
    """
    if '.' in game_name:
        return game_name.split('.', 1)[1]
    return game_name


class UnifiedGameGateway(kaggle_evaluation.core.templates.GameGateway):
    """Unified gateway for Gymnasium, PettingZoo, and Shimmy games.

    Automatically detects the framework from the game name and uses the
    appropriate driver.
    """

    def __init__(
        self,
        data_paths: tuple[str, ...] | None = None,
        game_name: str | None = None,
        server_names: list[str] | None = None,
        framework: str | None = None,
        **kwargs,
    ):
        # Allow Hearth to deserialize Pydantic Space models from remote_game_drivers
        allowed_modules = ['remote_game_drivers.gymnasium_remote_driver.serialization']

        # Detect framework to set appropriate defaults
        detected_framework = framework
        if detected_framework is None and game_name is not None:
            detected_framework = detect_framework(game_name)

        # Default server_names based on framework
        if server_names is None:
            if detected_framework == 'gymnasium':
                server_names = ['agent_0']  # Single agent
            else:
                server_names = ['agent_0', 'agent_1']  # Multiplayer

        super().__init__(
            data_paths=data_paths,
            allowed_modules=allowed_modules,
            game_name=game_name,
            server_names=server_names,
            **kwargs,
        )
        self.set_response_timeout_seconds(60 * 30)
        self.framework = framework  # User override, or None for auto-detect
        self.random_seed: int | None = None
        self.action_timeout: int | None = None

    def _create_driver(self, framework: str):
        """Create the appropriate driver for the framework."""
        if framework == 'gymnasium':
            import remote_game_drivers.gymnasium_remote_driver.game_driver as gym_driver

            relay_clients = {KaggleAgentId('agent_0'): self.client}
            return gym_driver.GameDriver(
                driver_config=self.driver_config,
                relay_clients=relay_clients,
                game_info=self.game_info,
            )

        elif framework == 'pettingzoo':
            import remote_game_drivers.pettingzoo_remote_driver.game_driver as pz_driver

            relay_clients = {KaggleAgentId(name): self.clients[name] for name in self.server_names}

            # Detect AEC vs Parallel from game module
            assert self.game_name is not None
            game_module = importlib.import_module(self.game_name)
            has_aec = hasattr(game_module, 'env')
            has_parallel = hasattr(game_module, 'parallel_env')

            if has_parallel and not has_aec:
                return pz_driver.ParallelGameDriver(
                    driver_config=self.driver_config,
                    relay_clients=relay_clients,
                    game_info=self.game_info,
                )
            return pz_driver.AECGameDriver(
                driver_config=self.driver_config,
                relay_clients=relay_clients,
                game_info=self.game_info,
            )

        elif framework == 'shimmy':
            import remote_game_drivers.shimmy_remote_driver.game_driver as shimmy_driver

            relay_clients = {KaggleAgentId(name): self.clients[name] for name in self.server_names}
            return shimmy_driver.OpenSpielGameDriver(
                driver_config=self.driver_config,
                relay_clients=relay_clients,
                game_info=self.game_info,
            )

        else:
            raise kaggle_evaluation.core.base_gateway.GatewayRuntimeError(
                kaggle_evaluation.core.base_gateway.GatewayRuntimeErrorType.GATEWAY_RAISED_EXCEPTION,
                f"Unknown framework '{framework}'. Supported frameworks: {sorted(KNOWN_FRAMEWORKS)}.",
            )

    def run_game(self) -> dict[str, float | int]:
        """Run the game and return agent scores."""
        if self.game_name is None:
            raise kaggle_evaluation.core.base_gateway.GatewayRuntimeError(
                kaggle_evaluation.core.base_gateway.GatewayRuntimeErrorType.GATEWAY_RAISED_EXCEPTION,
                'game_name must be set before running',
            )

        framework = self.framework or detect_framework(self.game_name)
        driver = self._create_driver(framework)

        # Determine the game name to pass to the driver
        # - PettingZoo: use full module path (e.g., 'pettingzoo.classic.tictactoe_v3')
        # - Shimmy/Gymnasium: strip the framework prefix (e.g., 'shimmy.tic_tac_toe' -> 'tic_tac_toe')
        if framework == 'pettingzoo':
            driver_game_name = self.game_name
        else:
            driver_game_name = strip_framework_prefix(self.game_name)

        return driver.run_game(driver_game_name)
