import collections
from typing import Any

# IMPORTANT: Import directly from shimmy.openspiel_compatibility, NOT from shimmy package.
# Importing `from shimmy import OpenSpielCompatibilityV0` triggers shimmy's __init__.py,
# which imports openai_gym_compatibility, which tries to import the old gym package.
# In Kaggle's Docker base image, the old gym is pre-installed and triggers a deprecation
# warning about NumPy 2.0 compatibility that causes the gateway to fail.
# Direct module import bypasses __init__.py and avoids this issue entirely.
from shimmy.openspiel_compatibility import OpenSpielCompatibilityV0

from remote_game_drivers.core.base_classes import PROCESS_TURN_ENDPOINT, AgentState, KaggleAgentId
from remote_game_drivers.gymnasium_remote_driver import game_driver
from remote_game_drivers.gymnasium_remote_driver.game_driver import GymGameData

# Games with known fundamental limitations that prevent them from working with Shimmy.
# All other OpenSpiel games are supported. Games in this list will trigger a warning.
UNSUPPORTED_GAMES: frozenset[str] = frozenset(
    [
        # Games without observation tensors - raises NotImplementedError
        'cribbage',
        # Games requiring external configuration files
        'efg_game',
        'nfg_game',
    ]
)


class OpenSpielGameDriver(game_driver.GameDriver):
    """Driver for OpenSpiel games via the Shimmy wrapper.

    Shimmy converts OpenSpiel games to PettingZoo AEC API.
    https://shimmy.farama.org/environments/open_spiel/

    Not all OpenSpiel games are supported. See the __game_is_supported() method for details.
    """

    def _get_agent_inputs(self) -> GymGameData:
        raise NotImplementedError('_get_agent_inputs is not used by OpenSpiel drivers')

    def get_still_playing(self) -> dict[KaggleAgentId, bool]:
        agents_still_playing: dict[KaggleAgentId, bool] = dict()
        for agent_id in self.env.terminations.keys():
            agents_still_playing[self._openspiel_to_kaggle_agent_id_map[agent_id]] = not (
                self.env.terminations[agent_id] or self.env.truncations[agent_id]
            )
        return agents_still_playing

    def start_new_game(self, game_name: str, random_seed=None, game_state=None, action_timeout=None):
        """Initialize a new OpenSpiel game.

        Args:
            game_name: OpenSpiel game name (e.g., "tic_tac_toe", "connect_four", "chess")
                      Can include wrapper parameters (e.g., "misere(game=tic_tac_toe())")
        """
        self.game_name: str = game_name
        import pyspiel  # type: ignore[import-untyped]

        loaded_game = pyspiel.load_game(game_name)
        self.env: OpenSpielCompatibilityV0 = OpenSpielCompatibilityV0(env=loaded_game, **self.game_config)
        self._init_shimmy_env_state(random_seed)
        self.episode_complete: bool = False
        self.rewards: dict[str, list[float | int]] = collections.defaultdict(list)
        self.random_seed = random_seed
        self.game_state = game_state
        self.action_timeout = action_timeout
        # OpenSpiel uses string agent IDs (e.g., "player_0", "player_1")
        self._kaggle_to_openspiel_agent_id_map: dict[KaggleAgentId, str] = dict()
        self._openspiel_to_kaggle_agent_id_map: dict[str, KaggleAgentId] = dict()
        for k_agent_id, os_agent_id in zip(self.agent_ids, self.env.agents):
            self._kaggle_to_openspiel_agent_id_map[k_agent_id] = os_agent_id
            self._openspiel_to_kaggle_agent_id_map[os_agent_id] = k_agent_id
        self.turn_count = 0
        self._align_agent_ids(env_agent_ids=self.env.agents)

    def step(self, action: Any) -> GymGameData | None:
        self.env.step(action)
        self.episode_complete = all(self.env.terminations.values()) or all(self.env.truncations.values())
        self.telemetry_logger.log_observation(self.observation)
        return None

    def get_results(self) -> dict[KaggleAgentId, float | int]:
        kaggle_rewards = dict()
        for os_agent_id, reward in self.rewards.items():
            kaggle_id = self._openspiel_to_kaggle_agent_id_map[os_agent_id]
            kaggle_rewards[kaggle_id] = sum(reward)
        return kaggle_rewards

    def _init_shimmy_env_state(self, random_seed: int | None = None) -> None:
        """Initialize shimmy environment state without calling reset().

        Shimmy's reset() method has a bug where it overwrites the game_name with
        game_type.short_name, which strips wrapper game parameters. For example,
        'misere(game=tic_tac_toe())' becomes just 'misere', causing pyspiel.load_game
        to fail with 'Missing parameter game'.

        This method replicates what reset() does but preserves the pre-loaded game,
        enabling support for wrapper games like misere, repeated_poker, etc.

        See: https://shimmy.farama.org/_modules/shimmy/openspiel_compatibility/
        """
        from gymnasium.utils import seeding

        self.env.np_random, self.env.np_seed = seeding.np_random(random_seed)
        self.env.agents = self.env.possible_agents[:]
        self.env._cumulative_rewards = {a: 0.0 for a in self.env.agents}
        self.env.rewards = {a: 0.0 for a in self.env.agents}
        self.env.terminations = {a: False for a in self.env.agents}
        self.env.truncations = {a: False for a in self.env.agents}
        self.env.infos = {a: {} for a in self.env.agents}
        self.env.game_length = 1
        self.env.game_state = self.env._env.new_initial_state()
        self.env.simultaneous_actions = dict()
        self.env._execute_chance_node()
        self.env._update_action_masks()
        self.env._update_observations()
        self.env._choose_next_agent()

    def _game_is_unsupported(self, game_name: str) -> bool:
        """Check if a game has known fundamental limitations.

        Returns True if the game is in UNSUPPORTED_GAMES and will likely fail.
        Returns False for all other games, which are expected to work.

        Known Unsupported Games:
        - **cribbage**: No observation tensors implemented in OpenSpiel.
        - **efg_game, nfg_game**: Require external game definition files.
        """
        return game_name in UNSUPPORTED_GAMES

    def run_game(self, game_name: str) -> dict[KaggleAgentId, float | int]:
        if self._game_is_unsupported(game_name):
            self.telemetry_logger.log_warning(
                f"Game '{game_name}' is in UNSUPPORTED_GAMES and will likely fail. See _game_is_unsupported() docstring for details."
            )

        self.start_new_game(game_name=game_name)
        for os_agent_id in self.env.agent_iter():
            _raw_observation, reward, termination, truncation, info = self.env.last()
            self.observation: dict = _raw_observation
            self.rewards[os_agent_id].append(reward)
            action_space = self.env.action_space(os_agent_id)
            kaggle_agent_id: KaggleAgentId = self._openspiel_to_kaggle_agent_id_map[os_agent_id]
            if termination or truncation:
                action = None
                status = AgentState.DONE
            else:
                action, reasoning = self.get_agent_action((action_space, self.observation), agent_id=kaggle_agent_id, info=info)
                status = AgentState.ACTIVE

            # Log step for replay compatibility
            agent_states = []
            for agent_id in self.agent_ids:
                os_id = self._kaggle_to_openspiel_agent_id_map[agent_id]
                is_current = os_id == os_agent_id
                agent_states.append(
                    {
                        'action': action if is_current else None,
                        'reward': sum(self.rewards.get(os_id, [0])),
                        'status': status
                        if is_current
                        else (AgentState.INACTIVE if not (self.env.terminations.get(os_id) or self.env.truncations.get(os_id)) else AgentState.DONE),
                    }
                )
            self.telemetry_logger.log_step(self.turn_count, agent_states)
            self.step(action)
            self.turn_count += 1

        results = self.get_results()
        self.env.close()
        return results

    def get_agent_action(self, game_data: GymGameData, agent_id: KaggleAgentId, info: dict | None = None) -> tuple[Any, str | None]:
        """Get an action from the agent via relay.

        Extends the base implementation to support the `info` parameter used by OpenSpiel games.
        """
        if agent_id not in self.relay_clients:
            raise RuntimeError(f'No relay client for agent {agent_id}. Available: {list(self.relay_clients.keys())}')

        action_space, observation = game_data
        serialized_action_space = self._serializer.serialize(action_space)
        serialized_observation = self._serializer.serialize(observation)

        # Send to agent via relay
        result = self.relay_clients[agent_id].send(PROCESS_TURN_ENDPOINT, serialized_action_space, serialized_observation, info)

        if not isinstance(result, dict) or 'action' not in result:
            raise ValueError(f'Invalid response from agent: expected dict with "action" key, got {result}')

        action = result['action']
        reasoning: str | None = result.get('reasoning')

        self.telemetry_logger.log_action(action)
        self.telemetry_logger.log_reasoning(reasoning)
        return action, reasoning
