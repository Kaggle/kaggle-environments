import abc
import collections
import importlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from types import ModuleType
from typing import Any, Union

import pettingzoo.utils.env

from remote_game_drivers.core.base_classes import AgentState, KaggleAgentId
from remote_game_drivers.gymnasium_remote_driver import game_driver
from remote_game_drivers.gymnasium_remote_driver.game_driver import GymGameData


class PettingZooBaseDriver(game_driver.GameDriver, abc.ABC):
    @abc.abstractmethod
    def _initialize_env(self, game_module: ModuleType) -> None:
        raise NotImplementedError

    def get_still_playing(self) -> dict[KaggleAgentId, bool]:
        # Returns True for agents that are still playing (not terminated and not truncated)
        agents_still_playing: dict[KaggleAgentId, bool] = dict()
        for agent_id in self.env.terminations.keys():  # ty: ignore
            agents_still_playing[self._pz_to_kaggle_agent_id_map[agent_id]] = not (
                self.env.terminations[agent_id] or self.env.truncations[agent_id]  # ty: ignore
            )
        return agents_still_playing

    def _get_agent_inputs(self) -> GymGameData:
        raise NotImplementedError('_get_agent_inputs is not used by PettingZoo drivers')

    def start_new_game(self, game_name: str, random_seed=None, game_state=None, action_timeout=None):
        """Initialize a new PettingZoo game.

        Args:
            game_name: Full module name of the PettingZoo game (e.g., 'pettingzoo.classic.chess_v6')
            random_seed: Optional random seed for reproducibility
            game_state: Optional serialized game state to restore (not yet implemented)
            action_timeout: Optional timeout for agent actions in seconds (not yet implemented)
        """
        self.game_name: str = game_name
        self.random_seed = random_seed
        self.game_state = game_state
        self.action_timeout = action_timeout
        self.env: Union[pettingzoo.AECEnv, pettingzoo.ParallelEnv]
        # TODO: refactor to accept game module rather than a str?
        game_module = importlib.import_module(name=game_name)
        self._initialize_env(game_module=game_module)
        self.episode_complete: bool = False
        self.rewards: dict[int, list[float | int]] = collections.defaultdict(list)
        # PettingZoo uses ints for agent IDs, while Kaggle may need more expressive names like "Gemini_2.5_Rethink".
        self._kaggle_to_pz_agent_id_map: dict[KaggleAgentId, int] = dict()
        self._pz_to_kaggle_agent_id_map: dict[int, KaggleAgentId] = dict()
        for k_agent_id, p_agent_id in zip(self.agent_ids, self.env.agents):
            pz_id = p_agent_id
            self._kaggle_to_pz_agent_id_map[k_agent_id] = pz_id
            self._pz_to_kaggle_agent_id_map[pz_id] = k_agent_id
        self.turn_count = 0
        self._align_agent_ids(env_agent_ids=self.env.agents)

    def get_results(self) -> dict[KaggleAgentId, float | int]:
        kaggle_rewards = dict()
        for pz_agent_id, reward in self.rewards.items():
            kaggle_id = self._pz_to_kaggle_agent_id_map[pz_agent_id]
            kaggle_rewards[kaggle_id] = sum(reward)
        return kaggle_rewards


class AECGameDriver(PettingZooBaseDriver):
    """Driver for games using the PettingZoo AEC API.
    https://pettingzoo.farama.org/api/aec/
    """

    def _initialize_env(self, game_module: ModuleType) -> None:
        self.env: pettingzoo.utils.env.AECEnv = game_module.env(**self.game_config)
        if self.random_seed is not None:
            self.env.reset(seed=self.random_seed)
        else:
            self.env.reset()

    def step(self, action: Any) -> GymGameData | None:
        self.env.step(action)
        # Episode is complete when no agents are still playing
        still_playing = self.get_still_playing()
        self.episode_complete = not any(still_playing.values())
        self.telemetry_logger.log_observation(self.observation)
        return None

    def run_game(self, game_name: str) -> dict[KaggleAgentId, float | int]:
        self.telemetry_logger.start_game_span(game_name)
        try:
            self.start_new_game(game_name=game_name)

            # Track turn order for verification/replay
            turn_history: list[dict] = []

            for pz_agent_id in self.env.agent_iter():
                _raw_observation, reward, termination, truncation, info = self.env.last()
                self.observation: dict = _raw_observation
                # env.reward() does not track the total rewards over time, so we need to manage it manually.
                # This is generally true for games that support multiple cycles without a reset, like RockPaperScissors.
                self.rewards[pz_agent_id].append(reward)
                action_space = self.env.action_space(pz_agent_id)
                kaggle_agent_id: KaggleAgentId = self._pz_to_kaggle_agent_id_map[pz_agent_id]
                if termination or truncation:
                    action = None
                    status = AgentState.DONE
                else:
                    action, reasoning = self.get_agent_action((action_space, self.observation), agent_id=kaggle_agent_id)
                    status = AgentState.ACTIVE
                    turn_history.append(
                        {
                            'turn': self.turn_count,
                            'kaggle_agent_id': str(kaggle_agent_id),
                            'pz_agent_id': pz_agent_id,
                            'action': action,
                        }
                    )

                # Log step for replay compatibility
                agent_states = []
                for agent_id in self.agent_ids:
                    pz_id = self._kaggle_to_pz_agent_id_map[agent_id]
                    is_current = pz_id == pz_agent_id
                    agent_states.append(
                        {
                            'action': action if is_current else None,
                            'reward': sum(self.rewards.get(pz_id, [0])),
                            'status': status
                            if is_current
                            else (
                                AgentState.INACTIVE if not (self.env.terminations.get(pz_id) or self.env.truncations.get(pz_id)) else AgentState.DONE
                            ),
                        }
                    )
                self.telemetry_logger.log_step(self.turn_count, agent_states)
                self.step(action)
                self.turn_count += 1

            # Store turn history in game_info for verification
            self.game_info['turn_history'] = turn_history

            results = self.get_results()
            self.env.close()
            return results
        finally:
            self.telemetry_logger.end_game_span()
            self.telemetry_logger.write_log_file()


class ParallelGameDriver(PettingZooBaseDriver):
    """Driver for games using the PettingZoo parallel API.
    https://pettingzoo.farama.org/api/parallel/
    """

    def _initialize_env(self, game_module: ModuleType) -> None:
        self.env: pettingzoo.utils.env.ParallelEnv = game_module.parallel_env(**self.game_config)
        if self.random_seed is not None:
            self.observations, self.infos = self.env.reset(seed=self.random_seed)
        else:
            self.observations, self.infos = self.env.reset()

    def step(self, action: dict[str, Any]) -> GymGameData | None:
        raise NotImplementedError

    def _get_action_for_agent(self, pz_agent_id: int) -> tuple[int, Any, str | None]:
        """Get action for a single agent. Returns (pz_agent_id, action, reasoning).

        This method is designed to be called in parallel via ThreadPoolExecutor.
        """
        kaggle_agent_id: KaggleAgentId = self._pz_to_kaggle_agent_id_map[pz_agent_id]
        action, reasoning = self.get_agent_action(
            game_data=(self.env.action_space(pz_agent_id), self.observations[pz_agent_id]),
            agent_id=kaggle_agent_id,
        )
        return pz_agent_id, action, reasoning

    def run_game(self, game_name: str) -> dict[KaggleAgentId, float | int]:
        self.telemetry_logger.start_game_span(game_name)
        try:
            self.start_new_game(game_name=game_name)
            while self.env.agents:
                actions: dict[int, Any] = dict()

                # Use ThreadPoolExecutor to collect actions from all agents in parallel.
                # This is I/O-bound (network calls to agents), so threads work well despite GIL.
                # max_workers=None lets Python choose based on CPU count, but we explicitly
                # set it to handle cases where players > CPUs (e.g., 10 players on 4 cores).
                with ThreadPoolExecutor(max_workers=len(self.env.agents)) as executor:
                    futures = {executor.submit(self._get_action_for_agent, pz_agent_id): pz_agent_id for pz_agent_id in self.env.agents}
                    for future in as_completed(futures):
                        pz_agent_id, action, reasoning = future.result()
                        actions[pz_agent_id] = action

                # Log step for replay compatibility (parallel games log all agents at once)
                agent_states = []
                for agent_id in self.agent_ids:
                    pz_id = self._kaggle_to_pz_agent_id_map[agent_id]
                    agent_states.append(
                        {
                            'action': actions.get(pz_id),
                            'reward': sum(self.rewards.get(pz_id, [0])),
                            'status': AgentState.ACTIVE,  # All agents act simultaneously in parallel games
                        }
                    )
                self.telemetry_logger.log_step(self.turn_count, agent_states)

                _raw_observations, rewards, terminations, truncations, _ = self.env.step(actions)
                self.observations: dict = _raw_observations
                for pz_agent_id, reward in rewards.items():
                    self.rewards[pz_agent_id].append(reward)
                self.episode_complete = all(terminations.values()) or all(truncations.values())
                self.telemetry_logger.log_observation(self.observations)
                self.turn_count += 1
            results = self.get_results()
            self.env.close()
            return results
        finally:
            self.telemetry_logger.end_game_span()
            self.telemetry_logger.write_log_file()
