# Ensure wheels are installed before importing any submodules
from remote_game_drivers.hearth_integrations.install_wheels import install_remote_game_drivers

install_remote_game_drivers()

# Uninstall old gym package to prevent deprecation warnings in Kaggle's Docker base image.
# The old gym package is pre-installed in the base image and causes errors when shimmy
# tries to import it. We use subprocess instead of pip API to ensure it works in all environments.
import subprocess
import sys

_gym_uninstall = subprocess.run(
    [sys.executable, '-m', 'pip', 'uninstall', '-y', 'gym'],
    capture_output=True,
    text=True,
)
# Ignore errors if gym is not installed (e.g., in local dev environments)

from . import game_driver, remote_agent

__all__ = ['game_driver', 'remote_agent']
