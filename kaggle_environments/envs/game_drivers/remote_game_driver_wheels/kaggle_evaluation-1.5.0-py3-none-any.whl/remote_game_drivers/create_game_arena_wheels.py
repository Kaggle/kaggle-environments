#!/usr/bin/env python3
"""Build third-party game driver dependency wheels for offline deployment.

Since remote_game_drivers is now part of kaggle_evaluation, this script only builds
wheels for third-party dependencies (gymnasium, pettingzoo, shimmy, etc.)
that are not included in the base Kaggle Docker image.
"""

import argparse
import subprocess
from pathlib import Path


def create_game_driver_wheels(hearth_dir: Path, output_dir: Path) -> None:
    """Build third-party game driver dependency wheels.

    Args:
        hearth_dir: Path to the hearth directory containing pyproject.toml.
        output_dir: Path where wheels should be placed.
    """
    print(f'Building third-party game driver wheels to {output_dir}', flush=True)

    output_dir.mkdir(parents=True, exist_ok=True)

    # Use uv pip compile to generate a requirements.txt from pyproject.toml with game-drivers extra.
    requirements_file = output_dir / 'requirements.txt'
    try:
        compile_cmd = [
            'uv',
            'pip',
            'compile',
            str(hearth_dir / 'pyproject.toml'),
            '--extra',
            'game-drivers',
            '--output-file',
            str(requirements_file),
            '--no-header',
            '--no-annotate',
        ]

        subprocess.run(
            compile_cmd,
            capture_output=True,
            text=True,
            check=True,
        )

        # Ensure all wheels are fresh and no extraneous wheels are retained.
        existing_wheels = list(output_dir.glob('*.whl'))
        for wheel in existing_wheels:
            wheel.unlink()

        # Note: Some dependencies may not be available as wheels for all platforms.
        # A few will download as tar.gz and need to be built at install time.
        # This conflicts with Kaggle datasets unpacking tar.gz files and needs to be managed later.
        pip_download_cmd = [
            'pip',
            'download',
            '--dest',
            str(output_dir),
            '--requirement',
            str(requirements_file),
        ]

        subprocess.run(
            pip_download_cmd,
            capture_output=True,
            text=True,
            check=True,
        )
    except Exception:
        raise
    finally:
        # Remove requirements file to avoid confusion with which of requirements.txt or pyproject.toml is main.
        if requirements_file.exists():
            requirements_file.unlink()

    wheel_count = len(list(output_dir.glob('*.whl')))
    tar_count = len(list(output_dir.glob('*.tar.gz')))
    print(f'Total wheels in {output_dir}: {wheel_count}', flush=True)
    if tar_count > 0:
        print(f'Source tar.gz distributions: {tar_count} (these will need to be built at install time)', flush=True)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Build third-party game driver dependency wheels for offline deployment.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Build wheels to default location (hearth/src/remote_game_drivers/game_driver_wheels)
  python create_game_arena_wheels.py
  
  # Build wheels to custom location
  python create_game_arena_wheels.py --dest /path/to/destination
""",
    )
    parser.add_argument('--dest', type=Path, help='Destination directory for wheels.')
    args = parser.parse_args()

    # hearth_dir is two levels up from remote_game_drivers (remote_game_drivers -> src -> hearth)
    hearth_dir = Path(__file__).parent.parent.parent

    if args.dest:
        output_dir = args.dest
    else:
        # Default to the location expected by gym_gateway
        output_dir = Path(__file__).parent / 'game_driver_wheels'

    create_game_driver_wheels(hearth_dir, output_dir)


if __name__ == '__main__':
    main()
