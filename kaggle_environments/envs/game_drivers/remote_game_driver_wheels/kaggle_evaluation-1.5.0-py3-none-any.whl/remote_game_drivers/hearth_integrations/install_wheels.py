"""Shared utility for installing remote_game_drivers from local wheels."""

import subprocess
from pathlib import Path

from kaggle_evaluation.core.base_gateway import GatewayRuntimeError, GatewayRuntimeErrorType

_installed = False


def install_remote_game_drivers() -> None:
    """Install the remote_game_drivers library from local wheels.

    Should work with zero internet access. Safe to call multiple times;
    installation only happens once.

    When deployed, gateway files are copied to kaggle_evaluation/<name>_gateway.py,
    so parent.parent from the gateway goes to the competition data directory
    containing game_driver_wheels.

    In local development/testing, wheels may not exist - in that case, we assume
    the packages are already installed via the dev environment and skip installation.
    """
    global _installed
    if _installed:
        return
    _installed = True

    # Find wheels relative to the calling gateway's location
    # This module is in hearth_integrations/, gateways are in hearth_integrations/<game>/
    # When deployed, the gateway is at kaggle_evaluation/<name>_gateway.py
    # and wheels are at kaggle_evaluation/../game_driver_wheels/
    # We use the import path of kaggle_evaluation to find the wheels
    import kaggle_evaluation

    assert kaggle_evaluation.__file__ is not None
    kaggle_eval_path = Path(kaggle_evaluation.__file__).parent
    wheels_path = kaggle_eval_path.parent / 'game_driver_wheels'

    wheels_files = list(wheels_path.rglob('*.whl'))

    # In local dev/test, wheels may not exist - assume packages are already installed
    if len(wheels_files) == 0:
        return

    uv_install = subprocess.run(
        f'uv pip install --system --no-index --no-deps {str(wheels_path)}/*.whl',
        shell=True,
        check=False,
        capture_output=True,
        text=True,
    )

    if uv_install.returncode != 0:
        msg = (
            'Failed to install game arena dependencies.'
            f'Exit code: {uv_install.returncode}\n'
            f'stdout:\n{uv_install.stdout}\n'
            f'stderr:\n{uv_install.stderr}'
        )
        raise GatewayRuntimeError(GatewayRuntimeErrorType.GATEWAY_RAISED_EXCEPTION, msg)
