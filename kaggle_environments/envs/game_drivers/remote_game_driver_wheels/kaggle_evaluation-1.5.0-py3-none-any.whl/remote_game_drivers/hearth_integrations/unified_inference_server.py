"""Unified Hearth inference server that supports Gymnasium, PettingZoo, and Shimmy agents."""

from typing import Type

import kaggle_evaluation.core.templates
from remote_game_drivers.hearth_integrations.install_wheels import install_remote_game_drivers
from remote_game_drivers.hearth_integrations.unified_gateway import UnifiedGameGateway

install_remote_game_drivers()


class UnifiedInferenceServer(kaggle_evaluation.core.templates.GameInferenceServer):
    """Unified inference server for Gymnasium, PettingZoo, and Shimmy agents.

    Creates an agent instance and registers its process_turn method directly.
    Extends GameInferenceServer to support multiplayer games via run_local_game().

    The agent class can be from any framework (Gymnasium, PettingZoo, or Shimmy).
    The framework is auto-detected from the game_name when running locally.
    """

    def __init__(self, agent_class: Type):
        """Initialize the inference server.

        Args:
            agent_class: The agent class to instantiate. Must have a process_turn method.
                Can be from remote_game_drivers.gymnasium_remote_driver.remote_agent,
                remote_game_drivers.pettingzoo_remote_driver.remote_agent, or
                remote_game_drivers.shimmy_remote_driver.remote_agent.
        """
        self.agent = agent_class()
        allowed_modules = ['remote_game_drivers.gymnasium_remote_driver.serialization']
        super().__init__(self.agent.process_turn, allowed_modules=allowed_modules)

    def _get_gateway_for_test(
        self,
        data_paths: tuple[str, ...] | None = None,
        file_share_dir: str | None = None,
        *args,
        **kwargs,
    ) -> kaggle_evaluation.core.templates.GameGateway:
        return UnifiedGameGateway(data_paths=data_paths, **kwargs)
