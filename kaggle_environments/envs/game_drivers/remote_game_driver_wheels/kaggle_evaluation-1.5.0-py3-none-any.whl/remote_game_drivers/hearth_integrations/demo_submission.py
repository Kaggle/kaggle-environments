"""Demo submission for game competitions using the unified inference server.

This file serves as a template for competition participants. Replace the
RandomAgent import with your own agent implementation.

Game names should be fully qualified:
- Gymnasium: 'Blackjack-v1', 'CartPole-v1', etc.
- PettingZoo: 'pettingzoo.classic.tictactoe_v3', 'pettingzoo.classic.chess_v6', etc.
- Shimmy/OpenSpiel: 'shimmy.tic_tac_toe', 'shimmy.connect_four', etc.
"""

import os

from remote_game_drivers.hearth_integrations.unified_inference_server import UnifiedInferenceServer

# Import your agent class here. Examples:
# from remote_game_drivers.gymnasium_remote_driver.remote_agent import RandomAgent
# from remote_game_drivers.pettingzoo_remote_driver.remote_agent import RandomAgent
# from remote_game_drivers.shimmy_remote_driver.remote_agent import RandomAgent
from remote_game_drivers.pettingzoo_remote_driver.remote_agent import RandomAgent

LOCAL_TEST_GAME_NAME = 'pettingzoo.classic.tictactoe_v3'

# Create the inference server with your agent
inference_server = UnifiedInferenceServer(RandomAgent)

if os.getenv('KAGGLE_IS_COMPETITION_RERUN'):
    # Production mode: serve predictions via gRPC
    inference_server.serve()
else:
    # Local testing mode: run a game locally
    # Replace with the appropriate game name for your competition
    opponent = RandomAgent()
    inference_server.run_local_game(
        opponents=[opponent],
        game_name=LOCAL_TEST_GAME_NAME,
    )
