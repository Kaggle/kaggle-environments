# Ensure wheels are installed before importing any submodules
from remote_game_drivers.hearth_integrations.install_wheels import install_remote_game_drivers

install_remote_game_drivers()

from . import game_driver, remote_agent, serialization

__all__ = ['game_driver', 'remote_agent', 'serialization']
