"""
Pydantic models for Gymnasium Space objects, enabling native Hearth networking support.

Space objects are converted to Pydantic models that Hearth can serialize/deserialize natively.
Observations and actions use primitives and numpy arrays already supported by Hearth.
"""

# future annotations allows us to have a bidirectional relationships more easily:
# composite models contain types within SpaceModelUnion, which itself contains the composite models.
from __future__ import annotations

import abc
from typing import Any, Dict, List, Literal, Union

import numpy as np
from gymnasium import spaces
from pydantic import BaseModel, field_validator, model_validator

from remote_game_drivers.core.base_classes import BaseSerializer

# Fundamental spaces:
# https://gymnasium.farama.org/api/spaces/fundamental/


def _convert_space_to_model(v: Any) -> Any:
    # Used to handle composite spaces
    if isinstance(v, spaces.Space):
        return SPACE_TO_MODEL[type(v)].model_validate(v, from_attributes=True)
    return v


class SpaceModel(abc.ABC, BaseModel):
    """Abstract base class for all space models."""

    @abc.abstractmethod
    def to_space(self) -> spaces.Space:
        raise NotImplementedError


class BoxModel(SpaceModel):
    type: Literal['Box'] = 'Box'
    low: Union[float, int, List[Any]]  # SupportsFloat | NDArray[Any]. Pydantic has limited support for nested lists.
    high: Union[float, int, List[Any]]  # SupportsFloat | NDArray[Any]. Pydantic has limited support for nested lists.
    shape: List[int]
    dtype: str

    @field_validator('low', 'high', mode='before')
    @classmethod
    def check_array(cls, v: Any) -> Any:
        if isinstance(v, np.ndarray):
            return v.tolist()
        return v

    @field_validator('dtype', mode='before')
    @classmethod
    def check_dtype(cls, v: Any) -> Any:
        if isinstance(v, (np.dtype, type)):
            return str(np.dtype(v))
        return str(v)

    def to_space(self) -> spaces.Box:
        return spaces.Box(
            low=np.array(self.low, dtype=np.dtype(self.dtype)),
            high=np.array(self.high, dtype=np.dtype(self.dtype)),
            shape=tuple(self.shape),
            dtype=np.dtype(self.dtype),  # type: ignore
        )


class DiscreteModel(SpaceModel):
    type: Literal['Discrete'] = 'Discrete'
    n: int

    def to_space(self) -> spaces.Discrete:
        return spaces.Discrete(self.n)


class MultiBinaryModel(SpaceModel):
    type: Literal['MultiBinary'] = 'MultiBinary'
    n: Union[int, List[int]]

    def to_space(self) -> spaces.MultiBinary:
        return spaces.MultiBinary(self.n)


class MultiDiscreteModel(SpaceModel):
    type: Literal['MultiDiscrete'] = 'MultiDiscrete'
    nvec: List[int]

    def to_space(self) -> spaces.MultiDiscrete:
        return spaces.MultiDiscrete(np.array(self.nvec))


class TextModel(SpaceModel):
    type: Literal['Text'] = 'Text'
    max_length: int
    min_length: int = 1
    charset: Union[List[str], str]

    @field_validator('charset', mode='before')
    @classmethod
    def check_charset(cls, v: Any) -> Any:
        if isinstance(v, frozenset):
            return list(v)
        return v

    @model_validator(mode='before')
    @classmethod
    def convert_from_space(cls, data: Any) -> Any:
        if isinstance(data, spaces.Text):
            return {
                'type': 'Text',
                'max_length': data.max_length,
                'min_length': data.min_length,
                'charset': data._char_set,
            }
        return data

    def to_space(self) -> spaces.Text:
        return spaces.Text(
            max_length=self.max_length,
            min_length=self.min_length,
            charset=frozenset(self.charset) if isinstance(self.charset, list) else self.charset,
        )


# Composite spaces:
# https://gymnasium.farama.org/api/spaces/composite/


class DictModel(SpaceModel):
    type: Literal['Dict'] = 'Dict'
    spaces: Dict[str, 'SpaceModelUnion']

    @model_validator(mode='before')
    @classmethod
    def convert_from_space(cls, data: Any) -> Any:
        if isinstance(data, spaces.Dict):
            return {'type': 'Dict', 'spaces': {k: _convert_space_to_model(s) for k, s in data.spaces.items()}}
        return data

    def to_space(self) -> spaces.Dict:
        return spaces.Dict({k: s.to_space() for k, s in self.spaces.items()})


class TupleModel(SpaceModel):
    type: Literal['Tuple'] = 'Tuple'
    spaces: List['SpaceModelUnion']

    @model_validator(mode='before')
    @classmethod
    def convert_from_space(cls, data: Any) -> Any:
        if isinstance(data, spaces.Tuple):
            return {'type': 'Tuple', 'spaces': [_convert_space_to_model(s) for s in data.spaces]}
        return data

    def to_space(self) -> spaces.Tuple:
        return spaces.Tuple([s.to_space() for s in self.spaces])


class SequenceModel(SpaceModel):
    type: Literal['Sequence'] = 'Sequence'
    feature_space: 'SpaceModelUnion'

    @model_validator(mode='before')
    @classmethod
    def convert_from_space(cls, data: Any) -> Any:
        if isinstance(data, spaces.Sequence):
            return {'type': 'Sequence', 'feature_space': _convert_space_to_model(data.feature_space)}
        return data

    def to_space(self) -> spaces.Sequence:
        return spaces.Sequence(self.feature_space.to_space())


class GraphModel(SpaceModel):
    type: Literal['Graph'] = 'Graph'
    node_space: Union[BoxModel, DiscreteModel]
    edge_space: Union[BoxModel, DiscreteModel] | None = None

    @model_validator(mode='before')
    @classmethod
    def convert_from_space(cls, data: Any) -> Any:
        if isinstance(data, spaces.Graph):
            return {
                'type': 'Graph',
                'node_space': _convert_space_to_model(data.node_space),
                'edge_space': _convert_space_to_model(data.edge_space) if data.edge_space else None,
            }
        return data

    def to_space(self) -> spaces.Graph:
        node_space = self.node_space.to_space()
        edge_space = self.edge_space.to_space() if self.edge_space else None
        return spaces.Graph(node_space=node_space, edge_space=edge_space)


class OneOfModel(SpaceModel):
    type: Literal['OneOf'] = 'OneOf'
    spaces: List['SpaceModelUnion']

    @model_validator(mode='before')
    @classmethod
    def convert_from_space(cls, data: Any) -> Any:
        if isinstance(data, spaces.OneOf):
            return {'type': 'OneOf', 'spaces': [_convert_space_to_model(s) for s in data.spaces]}
        return data

    def to_space(self) -> spaces.OneOf:
        return spaces.OneOf([s.to_space() for s in self.spaces])


SpaceModelUnion = Union[
    BoxModel,
    DiscreteModel,
    MultiBinaryModel,
    MultiDiscreteModel,
    TextModel,
    DictModel,
    TupleModel,
    SequenceModel,
    GraphModel,
    OneOfModel,
]

SPACE_TO_MODEL = {
    spaces.Box: BoxModel,
    spaces.Discrete: DiscreteModel,
    spaces.MultiBinary: MultiBinaryModel,
    spaces.MultiDiscrete: MultiDiscreteModel,
    spaces.Text: TextModel,
    spaces.Dict: DictModel,
    spaces.Tuple: TupleModel,
    spaces.Sequence: SequenceModel,
    spaces.Graph: GraphModel,
    spaces.OneOf: OneOfModel,
}


class GymSerializer(BaseSerializer[spaces.Space]):
    """Serialization and deserialization support for all Gymnasium Space object types.

    Leverages Hearth's native networking support for Pydantic models. Space objects are
    converted to Pydantic models and passed through directly to the networking layer.
    Observation values use types already supported by default (int, str, np.array, dict, etc).
    """

    def serialize(self, data: Any) -> Any:
        """Serialize game data for networking.

        Converts Gymnasium Space objects to Pydantic models (natively supported by Hearth).
        Other data types (observations, actions) are passed through as-is since they use
        primitives and numpy arrays that Hearth already supports.

        Returns:
            Pydantic model for Space objects, or the original data for other types.
        """
        if isinstance(data, spaces.Space):
            # Convert Space to Pydantic model - Hearth will handle the rest
            pydantic_model_class = SPACE_TO_MODEL[type(data)]
            model = pydantic_model_class.model_validate(data, from_attributes=True)
            return model
        else:
            # Observations and actions use primitives/numpy arrays - pass through
            return data

    def deserialize(self, data: Any) -> Any:
        """Deserialize data from networking format.

        Converts Pydantic Space models back to Gymnasium Space objects.
        All other types (observations, actions) are passed through as-is.

        Args:
            data: Either a Pydantic SpaceModel or a native type (primitives, numpy arrays, etc).

        Returns:
            Gymnasium Space object or observation value.
        """
        # If it's a Pydantic SpaceModel, convert to Space
        if isinstance(data, SpaceModel):
            return data.to_space()

        # Otherwise, it's already a native type (observation/action) - pass through
        return data
