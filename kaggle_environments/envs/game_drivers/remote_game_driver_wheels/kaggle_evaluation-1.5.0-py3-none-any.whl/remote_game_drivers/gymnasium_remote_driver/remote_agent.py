import abc
from typing import Any

import gymnasium.core
from gymnasium import spaces

from remote_game_drivers.gymnasium_remote_driver.serialization import GymSerializer, SpaceModel

GymAction = gymnasium.core.ActType


class RemoteAgent(abc.ABC):
    """Base class for all agents that interact with a gymnasium environment.

    Agents receive game data via relay networking. The action_space arrives as a
    Pydantic SpaceModel (which relay deserializes natively) and is converted to
    a Gymnasium Space before being passed to choose_action().

    From the agent's perspective, they are operating in a normal Gymnasium environment.
    """

    def __init__(self) -> None:
        self._serializer = GymSerializer()

    def process_turn(self, action_space: SpaceModel, observation: Any, info: Any | None = None) -> dict[str, Any]:
        """Entry point called by relay server. Converts Pydantic models to Gymnasium types.

        Args:
            action_space: Pydantic SpaceModel (deserialized by relay)
            observation: Native observation value (tuple, np.array, dict, etc.)
            info: Optional additional game-specific data (used by OpenSpiel/Shimmy)

        Returns:
            Dictionary with 'action' and optionally 'reasoning' keys.
        """
        gym_action_space = self._serializer.deserialize(action_space)
        result = self.choose_action(gym_action_space, observation, info=info)

        if isinstance(result, tuple) and len(result) == 2:
            action, reasoning = result
            response: dict[str, Any] = {'action': action}
            if reasoning is not None:
                response['reasoning'] = reasoning
            return response
        else:
            return {'action': result}

    @abc.abstractmethod
    def choose_action(
        self, action_space: spaces.Space, observation: gymnasium.core.ObsType, info: Any | None = None
    ) -> GymAction | tuple[GymAction, str | None]:
        """Choose an action given the current game state.

        This is the main method agents implement. They receive native Gymnasium types.

        Args:
            action_space: Gymnasium action space (e.g., spaces.Discrete, spaces.Box)
            observation: Gymnasium observation (tuple, np.array, dict, etc.)
            info: Optional additional game-specific data

        Returns:
            The chosen action, or a tuple of (action, reasoning)
        """
        raise NotImplementedError()


class RandomAgent(RemoteAgent):
    """Default agent implementation: move at random."""

    def choose_action(self, action_space: spaces.Space, observation: tuple[int], info: Any = None) -> GymAction:
        return action_space.sample()
